package tables;

public abstract class firstclass {
	
	public String ticket_cod;
	
}
