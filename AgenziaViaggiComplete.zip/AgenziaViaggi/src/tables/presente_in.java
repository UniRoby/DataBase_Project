package tables;

public abstract class presente_in {
	
	public int id_compagnia;
	public String id_aeroporto;
}
