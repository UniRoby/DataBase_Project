package tables;

public abstract class compagnia_aerea {
	
	public int id_compagnia;
	public String nome;
	
}
