package tables;

public abstract class numero_tel {
	public int numero;
	public int id_impiegato;
}
