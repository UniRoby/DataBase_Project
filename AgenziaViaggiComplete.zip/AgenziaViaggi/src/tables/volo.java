package tables;
import java.sql.Time;
import java.sql.Date;
public abstract class volo {
	public String aeroporto_partenza;
	public String aeroporto_destinanzione;
	public Time durata;
	public int numVolo;
	public Date data_partenza;
	public int numPasseggeri;
	public int id_compagnia;
	
}
