package tables;

public abstract class impiegato {

	
	public int id_impiegato;
	public int AnniLavoro;
	public int Stipendio;
	public int numVoli;
	public String[] Tipo= {"Pilota","Assistente"};
	public int compagnia;
	
	
	
	
	
}
