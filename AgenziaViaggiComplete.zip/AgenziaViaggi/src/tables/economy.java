package tables;

public abstract class economy {
	public String ticket_cod;
	public String[] buono= {"Family", "Student","U12"};
}
