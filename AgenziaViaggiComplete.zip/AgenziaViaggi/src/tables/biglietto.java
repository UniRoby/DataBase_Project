package tables;

public abstract class biglietto {
	
	public String ticket_cod;
	public int prezzo;
	public String numPosto;
	public String[] Tipo_bagaglio= {"S","M","L"};
	public String viaggiatore_cf;
	public int numVolo;
	
}
