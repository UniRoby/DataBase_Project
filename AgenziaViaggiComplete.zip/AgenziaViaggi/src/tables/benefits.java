package tables;

public abstract class benefits {
	
	public String ticket_cod;
	public String[] benefit ={"Streaming","Menu_Premium","Presa_Corrente"};
}
