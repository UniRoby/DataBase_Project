package tables;

public abstract class conosce {
	public String lingua_Nome;
	public int id_impiegato;
}
