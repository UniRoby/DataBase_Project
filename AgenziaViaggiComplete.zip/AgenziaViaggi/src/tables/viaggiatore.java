package tables;

public abstract class viaggiatore {
	public String cf;
	public String nome;
	public String cognome;
	public int et�;
}
