package tables;

public abstract class aeroporto {
	
	public String id_aeroporto;
	public String nome;
	public String citt�;
	
}
