package db;
import gui.*;
import java.lang.reflect.Field;
import java.sql.*;
import javax.swing.*;


import gui.Operation.OperationType;

public class DBHandler {

	// L'handler ha il compito di interpretare ed eseguire le query, per poi mostrare a schermo il risultato.
	
	public DBHandler(String query, String[] params, JTextArea result, OperationType type) {
		
		try {
			Connection con = DBConnectionPool.getConnection(); //recupero la connessione
			Statement st = con.createStatement();  //st rappresenta l'istruzione sql
			
			System.out.println("<DBHandler> Query di tipo " + type.toString() + " lanciata: " + query);
		
			// Si noti che le operazioni di INSERT, DELETE e UPDATE non producono output
			// Solo la SELECT, per sua stessa natura, prevede una stampa
			
			result.append("\n");

			if((type == OperationType.SELECT))
				{
				ResultSet rs = st.executeQuery(query); //ResultSet � un'interfaccia, rs ora contiene la tabella ottenuta con la query
                
				System.out.println("<DBHandler> Risultato query:");
				
				//rs.first(); // Mi posiziono sulla prima riga trovata
				
				int current = 0; // Contatore di righe selezionate
				
				//do
				while(rs.next())
				{ 
					//Output Handler
					System.out.print("	" + current + ". ");
					result.append("   " + current + ". ");
					
					if(!params[0].equals("*")) {
						
						// Stampo solo gli attributi richiesti
						
						String[] field =params[0].split(", "); //salvo in field gli attributi separati dalla virgola che voglio stampare presenti nella query
						
						if(type == OperationType.SELECT) {
							for(int i = 0; i < field.length; i++) {
								System.out.print(rs.getString(field[i]) + " ");
								result.append(rs.getString(field[i]) + " ");
							}
						}
						
					} else {     //caso in cui ci sia * dopo la SELECT
						Class<?> entity = Class.forName("tables." + params[1]); // Carica la classe in memoria e restituisce quel riferimento come istanza di Classe
						Field[] fields = entity.getFields(); //Restituisce una matrice contenente oggetti Field che riflettono tutti i campi pubblici accessibili della classe
						for(int i = 0; i < fields.length; i++) {
							System.out.print(rs.getString(fields[i].getName()) + " ");
							result.append(rs.getString(fields[i].getName()) + " ");
						}
					}
					System.out.print("\n");
					result.append("\n");
					current++;
				} 
					
				result.append("\n\n");
			} else { //Delete o Update
				st.executeUpdate(query);
				
				System.out.println("<DBHandler> Richiesta di " + type.toString() + " eseguita. Database aggiornato.");
				result.append("Richiesta di " + type.toString() + " eseguita. Database aggiornato.");
				result.append("\nRichiedere una SELECT per visualizzare le modifiche.\n\n\n");
			}
		} catch (SQLException e) {
			result.append("La query non ha generato alcun risultato.\n");
			System.out.println("<DBHandler> Fallimento della query (anomalia SQL)"+ e.getMessage()); 
		} catch (ClassNotFoundException | NoClassDefFoundError e) {
			result.append("La query non ha generato alcun risultato.\n");
			System.out.println("<DBHandler> Fallimento della query (tabella non trovata)");
		}
	}
	
	public DBHandler(String query, JTextArea result, OperationType type, int id) {
		System.out.println("<DBHandler> Lancio la query: " + query);
		try {
			Connection con = DBConnectionPool.getConnection();
			Statement st = con.createStatement();
			
			if((type == OperationType.SELECT)) 
				{	
				ResultSet rs = st.executeQuery(query);
				ResultSetMetaData md = rs.getMetaData();
				System.out.println("<DBHandler> Risultato query:");
				
				// print the column labels
				for (int i = 1; i <= md.getColumnCount(); i++) 
					result.append(md.getColumnLabel(i) + " ");
				result.append("\n");
				
				
				
				
				while(rs.next())
				 {
				    if(id==2){
				        result.append(String.valueOf(rs.getInt("NumVoli sotto le 2 ore")) + " ");
						result.append(String.valueOf(rs.getInt("id_impiegato")) + " ");
						result.append(rs.getString("Tipo"));
						result.append("\n");
				    }
					if(id == 8) {
						result.append(String.valueOf(rs.getInt("numVolo")) + " - ");
						result.append(rs.getString("cognome"));
						result.append("\n");
					}
					if(id == 10) {
						result.append(String.valueOf(rs.getInt("totale Speso") + " "));
						result.append(rs.getString("cf"));
						result.append("\n");
					}
					if(id == 11) {
						result.append(rs.getString("nome") + " ");
						result.append(rs.getString("cognome") + " ");
						result.append(String.valueOf(rs.getInt("et�")));
						result.append("\n");
					}
					
					if(id == 13) {
						
					    result.append(rs.getString("aeroporto_partenza") + " ");
						result.append(rs.getString("citt�") + " ");
						result.append("\n");
					}
					
					if(id == 14) {
				
							for (int i = 1; i <= md.getColumnCount(); i++)
								result.append(rs.getString(i) + " ");
							result.append("\n");
					}
					
				} 
				
				
				
				 
				
			} else {
				st.executeUpdate(query);
				
				
				System.out.println("<DBHandler> Richiesta di " + type.toString() + " eseguita. Database aggiornato.");
				result.append("Richiesta di " + type.toString() + "eseguita. Database aggiornato.");
				result.append("\nRichiedere una SELECT per visualizzare le modifiche.\n\n\n");
			}
		} catch (SQLException e) {
			result.append("La query non ha generato alcun risultato.\n");
			System.out.println("<DBHandler> Fallimento della query (anomalia SQL)"+e.getMessage());
		} catch (NoClassDefFoundError e) {
			result.append("La query non ha generato alcun risultato.\n");
			System.out.println("<DBHandler> Fallimento della query (tabella non trovata)");
		}
		
	}
	
	public void testConnection() throws SQLException {
		Connection con = DBConnectionPool.getConnection();
		DBConnectionPool.releaseConnection(con);
	}
	
}
