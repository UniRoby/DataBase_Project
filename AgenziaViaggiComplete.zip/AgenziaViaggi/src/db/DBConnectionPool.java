package db;

import java.sql.*;
import java.util.*;

public class DBConnectionPool {

	/*
	 * 	Driver della connessione al database di JDBC per MySQL
	 */
	
	private static List<Connection> freeDbConnections;

	static {
		freeDbConnections = new LinkedList<Connection>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver"); //forza il caricamento del driver e lancia una ClassNotFoundException
		} catch (ClassNotFoundException e) {
			System.out.println("<DBConnectionPool> Driver MySQL non trovati  " + e.getMessage());
		}
	}

	private static Connection createDBConnection() throws SQLException {
		Connection newConnection = null; //Connection � un'interfaccia
		
		/*String ip = "localhost";
		String port = "3306";
		
		String db = "agenziaviaggi";
		String username = "root";
		String password = "5798";
		
		String params = "";

	    newConnection = DriverManager.getConnection("jdbc:mysql://"+ ip + ":" + port + "/" + db + params, username, password);*/
		try {
			newConnection=DriverManager.getConnection("jdbc:mysql://localhost:3306/agenziaviaggi","root","5798");
			newConnection.setAutoCommit(true);
			if(newConnection!=null) {
				System.out.println("\n----------------------Connesso al DB----------------------------\n");
			}
		}catch(Exception e) {
			System.out.println("\n--------------------------Non connesso al DB------------------------\n");
		}
	
		
		return newConnection;
	}


	public static synchronized Connection getConnection() throws SQLException {
		Connection connection;

		if (!freeDbConnections.isEmpty()) {
			connection = (Connection) freeDbConnections.get(0);
			DBConnectionPool.freeDbConnections.remove(0);

			try {
				if (connection.isClosed())
					connection = DBConnectionPool.getConnection();
			} catch (SQLException e) {
				if(connection!=null)
					connection.close();
				
				connection = DBConnectionPool.getConnection();
			}
		} else {
			connection = DBConnectionPool.createDBConnection();
		}

		return connection;
	}

	public static synchronized void releaseConnection(Connection connection) {
		DBConnectionPool.freeDbConnections.add(connection);
	}
	
}
