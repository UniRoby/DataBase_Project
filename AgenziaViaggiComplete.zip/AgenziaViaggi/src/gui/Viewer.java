package gui;

public class Viewer {

	public static void main(String[] args) {
		
		/*
		 * 	 compilare questo file .java per lanciare l'applicazione. 
		 */
		
		System.out.println("<Viewer> Inizializzazione programma");
		
		new MainFrame();

	}

}
