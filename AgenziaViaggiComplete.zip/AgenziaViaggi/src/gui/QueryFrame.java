package gui;

import javax.swing.*;
import javax.swing.border.*;
import db.*;
import gui.Operation.AllowedTypes;
import gui.Operation.OperationType;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class QueryFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private static final int FRAME_WIDTH = 350;
	private static final int FRAME_HEIGHT = 425;
	
	private Operation op;
	private JTextArea result;
	
	public QueryFrame(Operation op, JTextArea result) {
		setSize(FRAME_WIDTH, FRAME_HEIGHT);
		setTitle("Costruttore di operazioni");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		this.op = op;
		this.result = result;
		
		if(!op.getComplex())
			add(new JScrollPane(createBuilder()));
		else {
			switch(op.getComplexId()) {
				case 2:
					add(new JScrollPane(createComplexBuilder_2()));
					break;
				case 8:
					add(new JScrollPane(createComplexBuilder_8()));
					break;
				case 10:
					add(new JScrollPane(createComplexBuilder_10()));
					break;
				case 11:
					add(new JScrollPane(createComplexBuilder_11()));
					break;
				case 12:
					add(new JScrollPane(createComplexBuilder_12()));
					break;
				case 13:
					add(new JScrollPane(createComplexBuilder_13()));
					break;
				case 14:
					add(new JScrollPane(createComplexBuilder_14()));
					break;
				default:
					System.out.println("<QueryFrame> Impossibile trovare l'id dell'operazione.");
			}
		}
		
		System.out.println("<QueryFrame> Costruttore di query creato con successo");
		
		pack();
		setVisible(true);
	}
	
	public JPanel createBuilder() {
		JPanel content = new JPanel(new GridLayout(op.getSize() + 1, 2));
		JButton enter = new JButton("Conferma");
		
		ArrayList<JTextField> values = new ArrayList<JTextField>();
		
		int i;
		
		if(op.getType() == OperationType.SELECT)
			i = 2;
		else if(op.getType() == OperationType.JOIN)
			i = op.getSize();
		else 
			i = 1;
		
		for(; i < op.getSize(); i++) {
			if((i == 1) && (op.getType() == OperationType.UPDATE)) {
				String[] sliced = op.getUnslicedParam(1).split(", ");
				for(int j = 0; j < sliced.length; j++) {
					JTextField anotherField = new JTextField(20);
					values.add(anotherField);
					content.add(new JLabel(sliced[j], SwingConstants.CENTER));
					content.add(anotherField);
				}
			} else {
				JTextField field = new JTextField(20);
				values.add(field);
				content.add(new JLabel(op.getParams(i), SwingConstants.CENTER));
				content.add(field);
			}
		}
		
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				for(JTextField x : values) {
					if(x.getText().isEmpty()) {
						System.out.println("<QueryFrame> Attenzione: riempire tutti i campi");
						result.append("[ ! ] Uno dei dati richiesti non � stato inserito.\n\n");
						return;
					}
				}
				
				result.append("Query lanciata: " + queryBuilder(values) + "\n");
				
				new DBHandler(
					queryBuilder(values), 
					op.getAllParams(), 
					result, 
					op.getType());
				
				System.out.println("<QueryFrame> Ritorno al frame principale");
				
				setVisible(false);
				
			}
		});
		
		JPanel enterContainer = new JPanel();
		
		enter.setCursor(new Cursor(Cursor.HAND_CURSOR));
		enterContainer.add(enter);
		content.add(enterContainer);
		content.setBorder(new EmptyBorder(20, 20, 20, 20));
		
		return content;
	}
	
	public String queryBuilder(ArrayList<JTextField> values) {
		System.out.println("<QueryFrame> Avvio il QueryBuilder");
		
		String query = null;
		
		if(op.getType() != OperationType.JOIN)
			query = op.getType().toString() + " "; // SELECT, INSERT..
		
		switch(op.getType()) {
			case DELETE:
				System.out.println("<QueryBuilder> OperationType: DELETE");
				
				query += "FROM " + op.getParams(0);
				
				System.out.println("<QueryBuilder> Query: " + query);
				
				if(op.getSize() > 1)
					query += " WHERE "; 
				
				for(int i = 1; i < op.getSize(); i++) {
					if(op.getParamClass(i) == AllowedTypes.STRING)
						query += op.getParams(i) + "=\"" + values.get(i - 1).getText() + "\"";
					else if(op.getParamClass(i) == AllowedTypes.DATE)
						query += op.getParams(i) + "='" + values.get(i - 1).getText() + "'";
					else
						query += op.getParams(i) + "=" + values.get(i - 1).getText();
					System.out.println("<QueryBuilder> Query: " + query);
					if((i + 1) != op.getSize())
						query += "&& ";
				}
				
				break;
				
			case INSERT:
				System.out.println("<QueryBuilder> OperationType: INSERT");
				
				query += "INTO " + op.getParams(0) + " VALUES (";
				
				System.out.println("<QueryBuilder> Query: " + query);
				
				for(int i = 1; i < op.getSize(); i++) {
					if(op.getParamClass(i) == AllowedTypes.STRING)
						query += "\"" + values.get(i - 1).getText() + "\"";
					else if(op.getParamClass(i) == AllowedTypes.DATE)
						query += "'"+ values.get(i - 1).getText() + "'";
					else
						query += values.get(i - 1).getText();
					System.out.println("<QueryBuilder> Query: " + query);
					if((i + 1) != op.getSize())
						query += ", ";
				}
				
				query += ")";
				
				break;
				
			case UPDATE:
				System.out.println("<QueryBuilder> OperationType: UPDATE");
				
				// Set multiplo
				
				if(op.getUnslicedParam(1).split(", ").length > 1) {
					String[] sliced = op.getUnslicedParam(1).split(", ");
					if(sliced.length > 1) {
						query += op.getParams(0) + " SET ";
						for(int i = 0; i < sliced.length; i++) {
							String[] sets = sliced[i].split(":");
							
							if(sets[1].equals("str")) 
								query += sets[0] + "=\"" + values.get(i).getText() + "\"";
							else
								query += sets[0] + "=" + values.get(i).getText();
							
							if((i + 1) != sliced.length)
								query += ", ";
							
						}
					} 
				} else if(op.getParamClass(1) == AllowedTypes.STRING) 
					query += op.getParams(0) + " SET " + op.getParams(1) + "=\"" + values.get(0).getText() + "\" WHERE ";
				else
					query += op.getParams(0) + " SET " + op.getParams(1) + "=" + values.get(0).getText();
				
				if(op.getSize() > 2) 
					query += " WHERE ";
				
				System.out.println("<QueryBuilder> Query: " + query);
				
				// Where
				for(int i = 2; i < op.getSize(); i++) {
					if(op.getParamClass(i) == AllowedTypes.STRING)
						query += op.getParams(i) + "=\"" + values.get(i - 1).getText() + "\"";
					else if(op.getParamClass(i) == AllowedTypes.DATE)
						query += op.getParams(i) + "='" + values.get(i -1).getText() + "'";
					else
						query += op.getParams(i) + "=" + values.get(i -1).getText();
					System.out.println("<QueryBuilder> Query: " + query);
					if((i + 1) != op.getSize())
						query += "&& ";
				}
				
				break;
				
			case SELECT:
				System.out.println("<QueryBuilder> OperationType: SELECT");
				
				query += op.getParams(0) + " FROM " + op.getParams(1);
				
				System.out.println("<QueryBuilder> Query: " + query);
				
				if(op.getSize() > 2)
					query +=  " WHERE ";
				
				for(int i = 2; i < op.getSize(); i++) {
					if(op.getParamClass(i) == AllowedTypes.STRING)
						query += op.getParams(i) + "=\"" + values.get(i - 2).getText() + "\"";
					else if(op.getParamClass(i) == AllowedTypes.DATE)
						query += op.getParams(i) + "'" + values.get(i - 2).getText() + "'";
					else
						query += op.getParams(i) + "=" + values.get(i - 2).getText() + "";
					System.out.println("<QueryBuilder> Query: " + query);
					if((i + 1) != op.getSize())
						query += " && ";
				}
				
				break;
				
			case JOIN:
				System.out.println("<QueryBuilder> OperationType: JOIN");
				
				query = "SELECT " + op.getParams(0) + " FROM " + op.getParams(1) + " JOIN " +
					     op.getParams(2) + " ON ";
				
				System.out.println("<QueryBuilder> Query: " + query);
				
				for(int i = 3; i < op.getSize(); i++) {
					query += op.getParams(i) + "=" + op.getParams(++i);
					if((++i) != op.getSize())
						query += " && ";
				}
				break;
				
			default:
				System.out.println("<QueryBuilder> OperationType non riconosciuta");
				break;
		}
		
		System.out.println("<QueryBuilder> Query inviata all'handler: " + query);
		
		return query;
	}
	
	public JPanel createComplexBuilder_8() {
		JPanel content = null;
		JButton enter = new JButton("Conferma");
		ArrayList<JTextField> values = new ArrayList<JTextField>();

		content = new JPanel(new GridLayout(3, 1));
		
		content.add(new JLabel("Nome"));
		JTextField nome = new JTextField();
		
		content.add(new JLabel("Cognome"));
		JTextField cognome = new JTextField();
			
		values.add(nome);
		values.add(cognome);
		content.add(nome);
		content.add(cognome);
		content.add(enter);
		
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				for(JTextField x : values) {
					if(x.getText().isEmpty()) {
						System.out.println("<QueryFrame> Attenzione: riempire tutti i campi");
						result.append("[ ! ] Uno dei dati richiesti non � stato inserito.\n\n");
						return;
					}
				}
				
				String query = "SELECT v.numVolo,vi.cognome "
						+ "FROM volo AS v, viaggiatore AS vi, biglietto AS b "
						+ "WHERE vi.cf = b.viaggiatore_cf AND b.volo_numVolo=v.numVolo AND " 
							+ "vi.nome = '" + nome.getText() + "' AND "
							+ "vi.cognome = \"" + cognome.getText() + "\"";
				
				result.append("Query lanciata: " + query + "\n");
				
				new DBHandler(
					query,
					result,
					OperationType.SELECT,
					op.getComplexId());
				
				System.out.println("<QueryFrame> Ritorno al frame principale");
				
				setVisible(false);
				
			}
		});
		
		return content;
		
	}
	
	public JPanel createComplexBuilder_2() {
		JPanel content = null;
		JButton enter = new JButton("Conferma");

		content = new JPanel(new GridLayout(3, 1));
		content.add(enter);
		
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String query = " SELECT COUNT(*) AS 'NumVoli sotto le 2 ore', id_impiegato,Tipo "
						+" FROM volo AS V, impiegato AS I "
						+ " WHERE V.id_compagnia = I.compagnia AND Tipo='Pilota' AND V.durata<'02:00' "
						+ " GROUP BY id_impiegato";
				
				result.append("Query lanciata: " + query + "\n");
				
				new DBHandler(
						query,
						result,
						OperationType.SELECT,
						op.getComplexId()
					);
				
				System.out.println("<QueryFrame> Ritorno al frame principale");
				
				setVisible(false);
				
			}
		});
		
		return content;
		
	}
	
	public JPanel createComplexBuilder_10() {
		JPanel content = null;
		JButton enter = new JButton("Conferma");
		ArrayList<JTextField> values = new ArrayList<JTextField>();

		content = new JPanel(new GridLayout(2, 1));
		content.add(new JLabel("Codice Fiscale"));
			
		JTextField value = new JTextField();
			
		values.add(value);
		content.add(value);
		content.add(enter);
		
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				for(JTextField x : values) {
					if(x.getText().isEmpty()) {
						System.out.println("<QueryFrame> Attenzione: riempire tutti i campi");
						result.append("[ ! ] Uno dei dati richiesti non � stato inserito.\n\n");
						return;
					}
				}
				
				String query = "SELECT SUM(B.prezzo) AS 'totale speso', V.cf"
						+ " FROM viaggiatore AS V, biglietto AS B "
						+ " WHERE V.cf=B.viaggiatore_cf AND V.cf = '" + value.getText()+"' ";
				
				result.append("Query lanciata: " + query + "\n");
				
				new DBHandler(
					query,
					result,
					OperationType.SELECT,
					op.getComplexId());
				
				System.out.println("<QueryFrame> Ritorno al frame principale");
				
				setVisible(false);
				
			}
		});
		
		return content;
		
	}

	public JPanel createComplexBuilder_11() {
		JPanel content = null;
		JButton enter = new JButton("Conferma");
		content = new JPanel(new GridLayout(1, 1));

		content.add(enter);
		
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String query = "SELECT V.nome, V.cognome, V.et� "
						+ "FROM viaggiatore AS V, biglietto AS B, economy AS E "
						+ "WHERE E.buono='U12' AND B.ticket_cod=E.ticket_cod AND B.viaggiatore_cf=V.cf ";
				
				result.append("Query lanciata: " + query + "\n");
				
				new DBHandler(
					query,
					result,
					OperationType.SELECT,
					op.getComplexId());
				
				System.out.println("<QueryFrame> Ritorno al frame principale");
				
				setVisible(false);
				
			}
		});
		
		return content;
		
	}

	public JPanel createComplexBuilder_12() {
		JPanel content = null;
		JButton enter = new JButton("Conferma");
		ArrayList<JTextField> values = new ArrayList<JTextField>();

		content = new JPanel(new GridLayout(3, 1));
		
		content.add(new JLabel("impiegato"));
		JTextField impiegato= new JTextField();
			
		values.add(impiegato);
		content.add(impiegato);
		content.add(enter);
		
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				for(JTextField x : values) {
					if(x.getText().isEmpty()) {
						System.out.println("<QueryFrame> Attenzione: riempire tutti i campi");
						result.append("[ ! ] Uno dei dati richiesti non � stato inserito.\n\n");
						return;
					}
				}
				
				String query = "UPDATE impiegato AS I "
						+ " SET I.stipendio = (I.stipendio + 200) "
						+ " WHERE I.id_impiegato = " + impiegato.getText() + " AND EXISTS("
						          + " SELECT C.id_Impiegato "
						          + " FROM conosce AS C "
						          + " WHERE C.id_impiegato = I.id_impiegato "
						          + " GROUP BY C.id_impiegato "
						          + " HAVING COUNT(*)>=2)";
				
				result.append("Query lanciata: " + query + "\n");
				
				new DBHandler(
					query,
					result,
					OperationType.UPDATE,
					op.getComplexId());
				
				System.out.println("<QueryFrame> Ritorno al frame principale");
				
				setVisible(false);
				
			}
		});
		
		return content;
		
	}
	
	public JPanel createComplexBuilder_13() {
		JPanel content = null;
		JButton enter = new JButton("Conferma");
		ArrayList<JTextField> values = new ArrayList<JTextField>();

		content = new JPanel(new GridLayout(2, 1));
		
		content.add(new JLabel("Numero Volo"));
		JTextField numvolo = new JTextField();
			
		values.add(numvolo);
		content.add(numvolo);
		content.add(enter);
		
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				for(JTextField x : values) {
					if(x.getText().isEmpty()) {
						System.out.println("<QueryFrame> Attenzione: riempire tutti i campi");
						result.append("[ ! ] Uno dei dati richiesti non � stato inserito.\n\n");
						return;
					}
				}
				
				String query = "SELECT v.aeroporto_partenza,a.citt� FROM volo AS v, aeroporto as a WHERE v.numVolo= " +
						numvolo.getText() +" AND v.aeroporto_partenza=a.id_aeroporto";
				
				result.append("Query lanciata: " + query + "\n");
				
				new DBHandler(
					query,
					result,
					OperationType.SELECT,
					op.getComplexId());
				
				System.out.println("<QueryFrame> Ritorno al frame principale");
				
				setVisible(false);
				
			}
		});
		
		return content;
		
	}

	public JPanel createComplexBuilder_14() {
		JPanel content = null;
		JButton enter = new JButton("Conferma");
		ArrayList<JTextField> values = new ArrayList<JTextField>();

		content = new JPanel(new GridLayout(3, 1));
		
		content.add(new JLabel("tabella"));
		JTextField tabella= new JTextField();
			
		values.add(tabella);
		content.add(tabella);
		content.add(enter);
		
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				for(JTextField x : values) {
					if(x.getText().isEmpty()) {
						System.out.println("<QueryFrame> Attenzione: riempire tutti i campi");
						result.append("[ ! ] Uno dei dati richiesti non � stato inserito.\n\n");
						return;
					}
				}
				
				String query = "SELECT * FROM "+ tabella.getText();
				
				result.append("Query lanciata: " + query + "\n");
				
				new DBHandler(
					query,
					result,
					OperationType.SELECT,
					op.getComplexId());
				
				System.out.println("<QueryFrame> Ritorno al frame principale");
				
				setVisible(false);
				
			}
		});
		
		return content;
		
	}
		
}
