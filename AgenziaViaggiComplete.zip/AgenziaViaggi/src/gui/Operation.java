package gui;

public final class Operation {

	public enum OperationType {SELECT, INSERT, DELETE, UPDATE, JOIN};
	public enum AllowedTypes {STRING, INTEGER, DATE, TIME};
	
	private OperationType type;
	private String[] params;
	private boolean complex;
	private int complexId;
	
	public Operation(OperationType type, String[] params) {
		this.type = type;
		this.params = params;
		this.complex = false;
		this.complexId = -1;
	}
	
	public Operation(OperationType type) {
		this.type = type;
		this.params = new String[] {"*"};
		this.complex = false;
		this.complexId = -1;;
	}
	
	public Operation(boolean complex, int id) {
		this.type = null;
		this.params = null;
		this.complex = true;
		this.complexId = id;
	}
	
	public Operation() {
		this.type = OperationType.SELECT;
		this.params = new String[] {"*"};
	}
	
	public OperationType getType() {
		return type;
	}

	public String[] getAllParams() {
		return params;
	}
	
	public String getParams(int i) {
		String[] parsed = params[i].split(":");
		return parsed[0];
	}
	
	public String getUnslicedParam(int i) {
		return params[i];
	}
	
	public AllowedTypes getParamClass(int i) {
		String[] type = params[i].split(":");
		AllowedTypes result = null;
		
		switch(type[1]) {
			case "int":
				result = AllowedTypes.INTEGER;
				break;
				
			case "date":
				result = AllowedTypes.DATE;
				break;
				
			case "str":
				result = AllowedTypes.STRING;
				break;
			case "time":
				result = AllowedTypes.TIME;
				break;
		}
		
		return result;
	}

	public int getSize() {
		return params.length;
	}
	
	public boolean getComplex() {
		return this.complex;
	}
	
	public int getComplexId() {
		return this.complexId;
	}
	
	
	
}
