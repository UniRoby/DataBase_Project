package gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import gui.Operation.OperationType;

public class MainFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private static final int FRAME_WIDTH = 600;
	private static final int FRAME_HEIGHT = 500;
	private static final int OPERATIONS = 15;
	
    /* 
       Il seguente array di operazione definisce un set di parametri chiave per costruire una query dedicata ..
	.. nel QueryBuilder.
	
	SELECT -> [0]  : fields
			  [1]  : table
			  [2+] : condition
			  
	UPDATE -> [0]  : table
	          [1]  : set
	          [2+] : condition
	
	INSERT -> [0]  : table
	          [1+] : values
	          
	DELETE -> [0]  : table
	          [1+] : condition
	          

	Inoltre, i tipi vengono rilevati in base alla loro desinenza.
	.. I tipi non si applicano ai nomi delle tabelle o degli attributi, ma solo ai parametri passati in input.
	.. es. SELECT WHERE conditions, UPDATE SETs values, etc.
	
	Type Flags: {param}:str   -> String
		   		{param}:int   -> Integer
		   		{param}:date  -> MySQL Date Format
		   		
	Infine, per interrogazioni particolarmente complesse sono state introdotte operazioni ad hoc dette "complesse" ..
	.. che si lanciano una query SQL senza essere costruite mano a mano.
	
	
	*/

	private final Operation[] op = {
		/*  1. */ new Operation(OperationType.INSERT, new String[] {"viaggiatore", "CF:str", "Nome:str", "Cognome:str", "Et�:int"}),
		/*  2. */ new Operation(true, 2),
		/*  3. */ new Operation(OperationType.DELETE, new String[] {"impiegato", "AnniLavoro:int"}),
		/*  4. */ new Operation(OperationType.UPDATE, new String[] {"biglietto", "prezzo:int", "NumPosto:str"}),
		/*  5. */ new Operation(OperationType.SELECT, new String[] {"nome", "aeroporto", "id_aeroporto:str"}), 
		/*  6. */ new Operation(OperationType.SELECT,new String[] {"*", "impiegato"}),
		/*  7. */ new Operation(OperationType.SELECT, new String[] {"benefit", "benefits", "ticket_cod:str"}),
		/*  8. */ new Operation(true, 8),
		/*  9. */ new Operation(OperationType.SELECT, new String[] {"numPasseggeri, numVolo", "volo"}),
		/* 10. */ new Operation(true, 10),
		/* 11. */ new Operation(true, 11),
		/* 12. */ new Operation(true, 12),
		/* 13. */ new Operation(true, 13),
		/* 14  */ new Operation(true,14)
	};
	
	private JTextArea result;
	
	public MainFrame() {
		setSize(FRAME_WIDTH, FRAME_HEIGHT);
		setTitle("Database AgenziaViaggi");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		add(createWest(), BorderLayout.WEST);
		add(createCenter(), BorderLayout.CENTER);
	
		System.out.println("<MainFrame> GUI creata con successo");

		setVisible(true);
	}
	
	/*Costruisce il pannello laterale che ospiter� un numero di bottoni pari al numeri di ..
	.. operazioni previste per questo database.
	 Inoltre, ad ogni bottone � assegnato un listener che apre un nuovo frame dedicato all'immissione dei dati.*/
	
	public JPanel createWest() {
		JPanel sidebar = new JPanel(new GridLayout(OPERATIONS, 1));
		
		sidebar.setBorder(new EmptyBorder(10, 10, 10, 10));
		
		for(int i = 0; i < op.length; i++) {
			JPanel padding = new JPanel(new GridLayout(1, 1));
			JButton button = new JButton("Operazione " + (i + 1));
			
			Operation op_tmp = op[i];
			int id_tmp = i + 1;
			
			padding.setBorder(new EmptyBorder(5, 0, 0, 0));
			button.addActionListener(x -> {
				System.out.println("<MainFrame> Operazione richiesta: ID " + id_tmp);
				result.append("[ ! ] Hai selezionato l'operazione " + id_tmp + ".\n\n");
				new QueryFrame(op_tmp, result);
			});
			
			button.setCursor(new Cursor(Cursor.HAND_CURSOR));
			
			padding.add(button);
			sidebar.add(padding);
		}
		
		System.out.println("<MainFrame> Pannello laterale creato con successo");
		System.out.println("<MainFrame> Operazioni caricate: " + OPERATIONS);
		
		return sidebar;
	}

	// Costruisce il pannello centrale in cui verranno stampati i risultati delle query.
	
	public JPanel createCenter() {
		JPanel center = new JPanel(new GridLayout(1, 1));
		center.setBorder(new EmptyBorder(10, 0, 10, 10));
		
		result = new JTextArea();
		result.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		result.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		result.setEditable(false);
		// Spiegazione delle query per l'utente.
		result.append("\nOperazioni CRUD:\n");
		result.append("1- Inserire un Viaggiatore\n");
		result.append("2- Stampare numero Voli di durata inferiore alle 2 ore ed id impiegato \n");
		result.append("3- Rimuovere un impiegato dato un certo numero di Anni di Lavoro\n");
		result.append("4- Modifica prezzo di un biglietto in base al numero del Posto\n");
		result.append("5- Stampare il nome di un dato aeroporto\n");
		result.append("6- Stampa tabella impiegato\n");
		result.append("7- Stampa i privilegi dato un ticket cod\n");
		result.append("8- Dato il nome e il cognome di un viaggiatore, stampare i relativi voli\n");
		result.append("9- Stampare numero Passegeri di ogni volo\n");
		result.append("10- Stampare il totale speso da un viaggiatore\n");
		result.append("11- Controllo validit� buono U12\n");
		result.append("12- Aumentare Stipendio di un dato impiegato se conosce due o pi� lingue\n");
		result.append("13- Dato un numero di volo stampare la citt� in cui si trova l'aeroporto di partenza\n");
		result.append("14- Select * from Tabella\n");
		
		center.add(new JScrollPane(result));
		
		System.out.println("<MainFrame> Pannello centrale creato con successo");
		
		return center;
	}
	
}
